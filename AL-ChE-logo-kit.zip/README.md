# AL ChE logo files — "Graphite and sky"

Logo: concept 19 (shared-stem AL with ChE threaded through it).

## Colours

| Role | Hex |
|---|---|
| Badge (graphite) | `#4c5157` |
| AL (white) | `#ffffff` |
| ChE (sky blue) | `#a6d7f0` |
| ChE on light backgrounds (deeper sky) | `#3a8db5` |

## Where each file goes

Copy the contents of this folder into the root of the website repository, keeping the folder structure.

### Site root (browsers look for these here)

| File | Used for |
|---|---|
| `favicon.ico` | Browser tab, 16/32/48 px, older browsers |
| `favicon.svg` | Browser tab, modern browsers |
| `favicon-16x16.png`, `favicon-32x32.png` | Fallback tab icons |
| `apple-touch-icon.png` | iPhone/iPad home screen, 180 px |
| `android-chrome-192x192.png`, `android-chrome-512x512.png` | Android home screen |
| `maskable-icon-512x512.png` | Android adaptive icon (cropped to a circle or squircle) |
| `site.webmanifest` | Tells Android which icons and colours to use |

### `assets/brand/`

| File | Used for |
|---|---|
| `logo.svg` | The main logo. Use this everywhere at 40 px and larger |
| `logo-icon.svg` | Simplified AL-only version for sizes under 40 px |
| `logo-mark-on-dark.svg` | No badge, white and sky blue, for the dark footer |
| `logo-mark-on-light.svg` | No badge, graphite and deeper sky, for white or stone backgrounds |
| `logo-512.png`, `logo-1024.png` | PNG copies for places that do not accept SVG |
| `github-avatar-1024.png` | GitHub profile picture (the mark is kept inside the circular crop) |
| `og-image.png` | 1200 × 630 preview image shown when a page link is shared |

### Snippets

| File | What to do with it |
|---|---|
| `head-snippet.html` | Paste inside `<head>` on every page |
| `header-snippet.html` | Logo and name for the left side of the navigation bar |

## Setup steps

1. Copy the files into the repository root as described above.
2. Paste `head-snippet.html` into the `<head>` of every page, and replace `YOUR-DOMAIN` with the real domain.
3. Replace the wordmark in the navigation bar with `header-snippet.html`.
4. Upload `assets/brand/github-avatar-1024.png` as the GitHub profile picture.
5. Commit and push, then hard-refresh the browser (favicons are cached aggressively).

## Notes

- The tab icon uses the simplified AL-only mark, because the ChE letters are too small to read below about 40 px.
- All paths in the snippets and the manifest start with `/`, which assumes the site is served from the root of its own domain. If it is served from `username.github.io/repository/`, add the repository name in front of each path.
- Keep clear space around the logo equal to at least a quarter of its width, and do not recolour, stretch or rotate it.
